require('./module-b.js');
