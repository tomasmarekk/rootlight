export type Glob = string;
