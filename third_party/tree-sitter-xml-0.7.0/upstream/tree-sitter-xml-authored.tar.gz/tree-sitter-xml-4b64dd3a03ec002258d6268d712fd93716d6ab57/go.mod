module github.com/tree-sitter-grammars/tree-sitter-xml

go 1.22

require github.com/tree-sitter/go-tree-sitter v0.24.0

require github.com/mattn/go-pointer v0.0.1 // indirect
