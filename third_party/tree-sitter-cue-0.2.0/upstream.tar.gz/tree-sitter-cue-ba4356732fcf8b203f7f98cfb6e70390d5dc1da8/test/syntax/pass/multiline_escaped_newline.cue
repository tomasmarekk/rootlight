a: """
	foo \
	bar
	"""
