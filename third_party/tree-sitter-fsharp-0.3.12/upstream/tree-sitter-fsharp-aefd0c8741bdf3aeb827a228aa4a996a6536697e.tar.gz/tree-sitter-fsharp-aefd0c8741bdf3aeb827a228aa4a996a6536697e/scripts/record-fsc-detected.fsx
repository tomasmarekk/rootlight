// Regenerates test/fsc-detected.txt: the corpus files where tree-sitter finds
// the same parse error F# finds, and at the same place.
//
// For every file in test/fsc-parse-failures.txt this asks FSC for the line of
// its first parse error, asks tree-sitter for the line of its first ERROR, and
// records the file only when the two agree within TOLERANCE. Files where
// tree-sitter errors for an unrelated reason are deliberately left out -- they
// would look like coverage while checking nothing. (FSharp.Core's inline IL
// files are the clearest case: FSC errors at line 467, tree-sitter at line 1.)
//
// The result is asserted by scripts/check-fsc-detected.fsx, which needs no
// NuGet package. Recording is append-only: a file already listed is kept even
// if this run cannot confirm it, so a regression can never be regenerated away.
// Removing an entry has to be a deliberate edit.
//
// Usage (from the repo root, with submodules checked out):
//     dotnet fsi scripts/record-fsc-detected.fsx
//
// Set TREE_SITTER to pick the CLI (default: `tree-sitter` on PATH).

#r "nuget: Fantomas.FCS, 7.0.5"

open System
open System.Diagnostics
open System.IO
open Fantomas.FCS

/// Must match check-fsc-detected.fsx.
let TOLERANCE = 2

let repoRoot = Path.GetFullPath(__SOURCE_DIRECTORY__ + "/..")
let listFile = Path.Combine(repoRoot, "test", "fsc-detected.txt")
let failuresFile = Path.Combine(repoRoot, "test", "fsc-parse-failures.txt")

let treeSitter =
    match Environment.GetEnvironmentVariable "TREE_SITTER" with
    | null | "" -> "tree-sitter"
    | value -> value

let readEntries path =
    if File.Exists path then
        File.ReadAllLines path
        |> Array.map (fun line -> line.Trim())
        |> Array.filter (fun line -> line <> "" && not (line.StartsWith "#"))
    else
        [||]

/// Line of the first parse error FSC reports, if any.
let fscErrorLine (rel: string) =
    try
        let text = File.ReadAllText(Path.Combine(repoRoot, rel))
        let _ast, diags = Parse.parseFile false (Text.SourceText.ofString text) []

        diags
        |> List.filter (fun d ->
            d.Severity = Diagnostics.FSharpDiagnosticSeverity.Error && d.SubCategory = "parse")
        |> List.choose (fun d -> d.Range |> Option.map (fun r -> r.StartLine))
        |> function
            | [] -> None
            | lines -> Some(List.min lines)
    with _ ->
        None

/// Line of each file's first tree-sitter ERROR.
let treeSitterErrorLines (paths: string[]) =
    let listing = Path.GetTempFileName()

    try
        File.WriteAllLines(listing, paths)

        let psi = ProcessStartInfo(treeSitter)
        for arg in [ "parse"; "-q"; "-t"; "--paths"; listing ] do
            psi.ArgumentList.Add arg
        psi.WorkingDirectory <- repoRoot
        psi.RedirectStandardOutput <- true
        psi.RedirectStandardError <- true
        psi.UseShellExecute <- false

        use proc =
            try
                Process.Start psi
            with e ->
                eprintfn "could not run `%s`: %s" treeSitter e.Message
                eprintfn "Set TREE_SITTER to the CLI path, or put it on PATH."
                exit 2

        // Drain both pipes concurrently; reading one to completion first
        // deadlocks as soon as the other fills its buffer.
        let stdoutTask = proc.StandardOutput.ReadToEndAsync()
        let stderrTask = proc.StandardError.ReadToEndAsync()
        proc.WaitForExit()
        let stdout = stdoutTask.Result
        let stderr = stderrTask.Result

        // Reporting on no files means the CLI failed, not that nothing errors.
        // Recording that silence would write an empty list and quietly drop
        // every assertion.
        let reported =
            stdout.Split('\n') |> Array.filter (fun l -> l.StartsWith "examples/") |> Array.length

        if reported = 0 && paths.Length > 0 then
            eprintfn "`%s parse` reported on none of the %d files (exit %d)." treeSitter paths.Length proc.ExitCode
            eprintfn "Refusing to record an empty list."
            eprintfn ""
            eprintfn "%s" (stderr.Trim())
            exit 2

        stdout.Split('\n')
        |> Array.map (fun line -> line.TrimEnd('\r'))
        |> Array.choose (fun line ->
            if not (line.StartsWith "examples/") then
                None
            else
                let marker = line.IndexOf "(ERROR ["

                if marker < 0 then
                    None
                else
                    let rest = line.Substring(marker + 8)
                    let row = rest.Substring(0, rest.IndexOf ',')
                    Some(line.Split('\t').[0].TrimEnd(), int row + 1))
        |> Map.ofArray
    finally
        File.Delete listing

let rejected = readEntries failuresFile
printfn "Asking FSC and tree-sitter about %d files..." rejected.Length

let tsLines = treeSitterErrorLines rejected

let confirmed =
    rejected
    |> Array.choose (fun rel ->
        match fscErrorLine rel, Map.tryFind rel tsLines with
        | Some fsc, Some ts when abs (ts - fsc) <= TOLERANCE -> Some(rel, fsc)
        | _ -> None)
    |> Map.ofArray

// Append-only: keep anything already recorded, even if unconfirmed this run.
let existing =
    readEntries listFile
    |> Array.map (fun line ->
        let parts = line.Split('\t')
        parts.[0], int parts.[1])
    |> Map.ofArray

let merged =
    Map.fold (fun acc path line -> Map.add path line acc) existing confirmed
    |> Map.toArray
    |> Array.sortBy fst

let mislocated =
    rejected
    |> Array.filter (fun rel ->
        match fscErrorLine rel, Map.tryFind rel tsLines with
        | Some fsc, Some ts -> abs (ts - fsc) > TOLERANCE
        | _ -> false)

let lines =
    [| "# Corpus files where tree-sitter finds the same parse error F# finds,"
       "# at the same line (within 2)."
       "#"
       "# Generated by scripts/record-fsc-detected.fsx, asserted by"
       "# scripts/check-fsc-detected.fsx. Append-only: an entry that starts"
       "# failing is a regression to fix, not a line to delete."
       "#"
       sprintf "# %d confirmed of %d files F#'s parser rejects." confirmed.Count rejected.Length
       sprintf "# %d more produce an ERROR somewhere else in the file and are not counted." mislocated.Length
       ""
       yield! merged |> Array.map (fun (path, line) -> sprintf "%s\t%d" path line) |]

// LF regardless of host OS, matching `* text eol=lf` in .gitattributes.
File.WriteAllText(listFile, String.concat "\n" lines + "\n")

printfn "confirmed %d, mislocated %d, recorded %d" confirmed.Count mislocated.Length merged.Length
