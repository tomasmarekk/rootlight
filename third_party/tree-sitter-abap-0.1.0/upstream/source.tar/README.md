# tree-sitter-abap

A **highlight-grade** [tree-sitter](https://tree-sitter.github.io) grammar for
ABAP: syntax highlighting, outline, brackets, and indentation for editors —
built for the [zed-abap](https://github.com/zooloo303/zed-abap) Zed extension,
usable anywhere tree-sitter runs.

## Design

This is deliberately **not** a full ABAP parser. ABAP has hundreds of
statement types; parsing them all is [abaplint](https://abaplint.org)'s job.
This grammar models exactly what an editor UI needs:

- **Lexical layer** — case-insensitive keywords, `*` full-line comments
  (column 1, via a small external scanner), `"` inline comments, `'...'` /
  `` `...` `` literals, `|...{ expr }...|` string templates, `##pragmas`,
  field symbols `<fs>`, namespaced identifiers (`/DRU/CL_FOO`), `!`-escaped
  parameter names.
- **Statement layer** — a statement is any token sequence terminated by `.`,
  with `:`/`,` chaining. Statements the grammar doesn't know stay valid as
  token soup — unknown syntax degrades gracefully instead of erroring.
- **Structure layer** (outline / folding / indent): `CLASS ... DEFINITION /
  IMPLEMENTATION ... ENDCLASS`, `INTERFACE ... ENDINTERFACE`,
  `METHOD ... ENDMETHOD`, `FORM / FUNCTION / MODULE` blocks, `METHODS` /
  `DATA` / `TYPES` / … declarations with named entries, `REPORT` / `PROGRAM` /
  `FUNCTION-POOL` headers.

Keyword *highlighting* beyond structural keywords is done in
`queries/highlights.scm` with case-insensitive `#match?` predicates over
identifiers — keeping the parse table small and the parser fast and robust.

## Status

Parses all 750 `.abap` files of the [abapGit](https://github.com/abapGit/abapGit)
codebase with **zero ERROR nodes** at ~30 MB/s (tree-sitter 0.25).

## Development

```sh
npm install
npx tree-sitter generate   # after editing grammar.js
npx tree-sitter test       # corpus tests in test/corpus/
npx tree-sitter parse examples/*.abap
```

## License

MIT © Neil Ward
