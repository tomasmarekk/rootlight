*&---------------------------------------------------------------------*
*& Report zdemo
*&---------------------------------------------------------------------*
REPORT zdemo.

CLASS lcl_demo DEFINITION DEFERRED.

DATA: gv_count TYPE i,
      gv_name  TYPE string VALUE 'initial ''quoted'' text'.

CLASS lcl_demo DEFINITION FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES zif_demo.
    METHODS: constructor IMPORTING iv_x TYPE i DEFAULT 5,
             run RETURNING VALUE(rv_result) TYPE string.
    CLASS-METHODS factory RETURNING VALUE(ro_obj) TYPE REF TO lcl_demo.
  PRIVATE SECTION.
    DATA mv_x TYPE i ##NEEDED.
    TYPES: BEGIN OF ty_row,
             id   TYPE i,
             name TYPE string,
           END OF ty_row.
    FIELD-SYMBOLS <fs_any> TYPE any.
ENDCLASS.

CLASS lcl_demo IMPLEMENTATION.
  METHOD constructor.
    mv_x = iv_x * 2 ** 3.
  ENDMETHOD.

  METHOD run.
    DATA(lv_local) = VALUE string_table( ( `a` ) ( `b` ) ).
    LOOP AT lv_local ASSIGNING FIELD-SYMBOL(<lv_line>).
      rv_result = |{ rv_result } and { <lv_line> }|. " inline comment
    ENDLOOP.
    SELECT SINGLE * FROM t000 INTO @DATA(ls_t000) WHERE mandt = @sy-mandt.
    IF sy-subrc = 0 AND ls_t000-mtext IS NOT INITIAL.
      rv_result = rv_result && ls_t000-mtext.
    ENDIF.
    me->helper( iv_val = 1 iv_txt = 'x' ).
    zcl_util=>static_call( ).
  ENDMETHOD.

  METHOD zif_demo~process.
    WRITE: / 'hello'(001), / gv_name.
  ENDMETHOD.
ENDCLASS.

FORM legacy_form USING iv_a TYPE i CHANGING cv_b TYPE string.
  PERFORM other_form.
ENDFORM.
