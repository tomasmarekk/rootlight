# Examples

Real-world parse fixtures for `tree-sitter parse examples/*.abap`.

- `zdemo_showcase.prog.abap` — hand-written feature showcase (this repo, MIT).
- `zcl_abapgit_gitv2_porcelain.clas.abap`, `zif_abapgit_repo_srv.intf.abap` —
  from [abapGit](https://github.com/abapGit/abapGit), MIT License,
  Copyright (c) abapGit contributors. Included unmodified as parser fixtures.
