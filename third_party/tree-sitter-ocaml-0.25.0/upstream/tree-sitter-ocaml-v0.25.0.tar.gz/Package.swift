// swift-tools-version:5.6

import Foundation
import PackageDescription

let package = Package(
    name: "TreeSitterOCaml",
    products: [
        .library(name: "TreeSitterOCaml", targets: ["TreeSitterOCaml"]),
    ],
    dependencies: [
        .package(url: "https://github.com/tree-sitter/swift-tree-sitter", from: "0.10.0"),
    ],
    targets: [
        .target(
            name: "TreeSitterOCaml",
            path: ".",
            sources: [
                "grammars/ocaml/src/parser.c",
                "grammars/ocaml/src/scanner.c",
                "grammars/interface/src/parser.c",
                "grammars/interface/src/scanner.c",
                "grammars/type/src/parser.c",
                "grammars/type/src/scanner.c",
            ],
            resources: [
                .copy("queries")
            ],
            publicHeadersPath: "bindings/swift",
            cSettings: [.headerSearchPath("grammars/ocaml/src")]
        ),
        .testTarget(
            name: "TreeSitterOCamlTests",
            dependencies: [
                .product(name: "SwiftTreeSitter", package: "swift-tree-sitter"),
                "TreeSitterOCaml",
            ],
            path: "bindings/swift/TreeSitterOCamlTests"
        )
    ],
    cLanguageStandard: .c11
)
