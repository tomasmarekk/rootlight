module github.com/gdamore/tree-sitter-d

go 1.23

require github.com/tree-sitter/go-tree-sitter v0.24.0

require github.com/mattn/go-pointer v0.0.1 // indirect
