// SPDX-FileCopyrightText: 2024 tree-sitter contributors
//
// SPDX-License-Identifier: MIT

module github.com/tree-sitter/tree-sitter-nim

go 1.22

require github.com/smacker/go-tree-sitter v0.0.0-20230720070738-0d0a9f78d8f8
